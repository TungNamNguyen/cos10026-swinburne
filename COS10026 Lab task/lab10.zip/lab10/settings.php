<!doctype html>
<html lang = "en">
<head>
<meta charset="utf-8">
<meta name = "Nguyen Nam Tung " content = "Creating web application Lab10 "/>
<title>Connecting to a database from PHP</title>
</head>
<body>
<?php 
    $host = "feenix-mariadb.swin.edu.au";
    $user = "s103181157";
    $pwd = "123456nAm#";
    $sql_db = "s103181157_db";
?>
</body>
</html>